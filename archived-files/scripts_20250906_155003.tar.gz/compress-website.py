#!/usr/bin/env python3
"""
Website Compression Script for KW Wizards Basketball
Compresses CSS and HTML files to improve page load performance
"""

import os
import re
import gzip
import shutil
from pathlib import Path

def compress_css(css_content):
    """
    Compress CSS by removing unnecessary whitespace, comments, and optimizing rules
    """
    # Remove CSS comments
    css_content = re.sub(r'/\*.*?\*/', '', css_content, flags=re.DOTALL)
    
    # Remove unnecessary whitespace
    css_content = re.sub(r'\s+', ' ', css_content)
    
    # Remove spaces around certain characters
    css_content = re.sub(r'\s*([{}:;,>+~])\s*', r'\1', css_content)
    
    # Remove trailing semicolons before closing braces
    css_content = re.sub(r';}', '}', css_content)
    
    # Remove unnecessary quotes around font names (keep quotes for multi-word fonts)
    css_content = re.sub(r"font-family:\s*['\"]([^'\"]*)['\"]", lambda m: f"font-family:{m.group(1)}" if ' ' not in m.group(1) else m.group(0), css_content)
    
    # Compress color values
    css_content = re.sub(r'#([0-9a-fA-F])\1([0-9a-fA-F])\2([0-9a-fA-F])\3', r'#\1\2\3', css_content)
    
    # Remove leading/trailing whitespace
    css_content = css_content.strip()
    
    return css_content

def compress_html(html_content):
    """
    Compress HTML by removing unnecessary whitespace while preserving functionality
    """
    # Preserve content within <pre>, <code>, <script>, and <style> tags
    preserved_blocks = []
    preserve_tags = ['pre', 'code', 'script', 'style']
    
    for tag in preserve_tags:
        pattern = f'<{tag}[^>]*>.*?</{tag}>'
        matches = re.findall(pattern, html_content, flags=re.DOTALL | re.IGNORECASE)
        for i, match in enumerate(matches):
            placeholder = f'__PRESERVE_{tag.upper()}_{i}__'
            preserved_blocks.append((placeholder, match))
            html_content = html_content.replace(match, placeholder, 1)
    
    # Remove HTML comments (but keep conditional comments for IE)
    html_content = re.sub(r'<!--(?!\s*\[if\s)(?!.*\[endif\]).*?-->', '', html_content, flags=re.DOTALL)
    
    # Remove unnecessary whitespace between tags
    html_content = re.sub(r'>\s+<', '><', html_content)
    
    # Remove whitespace at the beginning and end of lines
    html_content = re.sub(r'^\s+|\s+$', '', html_content, flags=re.MULTILINE)
    
    # Compress multiple whitespace characters into single spaces
    html_content = re.sub(r'\s{2,}', ' ', html_content)
    
    # Remove empty lines
    html_content = re.sub(r'\n\s*\n', '\n', html_content)
    
    # Restore preserved blocks
    for placeholder, original in preserved_blocks:
        # For CSS within <style> tags, apply CSS compression
        if placeholder.startswith('__PRESERVE_STYLE_'):
            # Extract CSS content and compress it
            style_match = re.match(r'(<style[^>]*>)(.*?)(<\/style>)', original, flags=re.DOTALL)
            if style_match:
                opening_tag, css_content, closing_tag = style_match.groups()
                compressed_css = compress_css(css_content)
                original = opening_tag + compressed_css + closing_tag
        
        html_content = html_content.replace(placeholder, original, 1)
    
    return html_content.strip()

def create_gzip_version(file_path):
    """
    Create a gzipped version of the file for servers that support pre-compressed files
    """
    with open(file_path, 'rb') as f_in:
        with gzip.open(f'{file_path}.gz', 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)

def compress_file(file_path):
    """
    Compress a single HTML or CSS file
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
        
        original_size = len(content.encode('utf-8'))
        
        if file_path.suffix.lower() == '.html':
            compressed_content = compress_html(content)
        elif file_path.suffix.lower() == '.css':
            compressed_content = compress_css(content)
        else:
            return None, None, None
        
        compressed_size = len(compressed_content.encode('utf-8'))
        
        # Create backup
        backup_path = file_path.with_suffix(file_path.suffix + '.backup')
        shutil.copy2(file_path, backup_path)
        
        # Write compressed content
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write(compressed_content)
        
        # Create gzipped version for server optimization
        create_gzip_version(file_path)
        
        return original_size, compressed_size, backup_path
    
    except Exception as e:
        print(f"Error compressing {file_path}: {e}")
        return None, None, None

def main():
    """
    Main function to compress all HTML and CSS files in the website
    """
    website_dir = Path('.')
    
    # Find all HTML and CSS files
    html_files = list(website_dir.glob('*.html'))
    css_files = list(website_dir.glob('*.css'))
    
    all_files = html_files + css_files
    
    print("🚀 KW Wizards Basketball Website Compression Tool")
    print("=" * 50)
    print(f"Found {len(html_files)} HTML files and {len(css_files)} CSS files")
    print()
    
    total_original = 0
    total_compressed = 0
    compressed_files = []
    
    for file_path in all_files:
        if file_path.name.endswith('.backup'):
            continue
            
        print(f"Compressing: {file_path.name}")
        original_size, compressed_size, backup_path = compress_file(file_path)
        
        if original_size and compressed_size:
            reduction = ((original_size - compressed_size) / original_size) * 100
            total_original += original_size
            total_compressed += compressed_size
            compressed_files.append({
                'name': file_path.name,
                'original': original_size,
                'compressed': compressed_size,
                'reduction': reduction,
                'backup': backup_path
            })
            print(f"  ✅ {original_size:,} bytes → {compressed_size:,} bytes ({reduction:.1f}% reduction)")
        else:
            print(f"  ❌ Failed to compress")
        
        print()
    
    # Summary
    if total_original > 0:
        total_reduction = ((total_original - total_compressed) / total_original) * 100
        print("📊 COMPRESSION SUMMARY")
        print("=" * 50)
        print(f"Total original size:  {total_original:,} bytes ({total_original/1024:.1f} KB)")
        print(f"Total compressed size: {total_compressed:,} bytes ({total_compressed/1024:.1f} KB)")
        print(f"Total reduction: {total_original - total_compressed:,} bytes ({total_reduction:.1f}%)")
        print()
        
        print("🎯 PERFORMANCE BENEFITS:")
        print(f"• Faster page loads: ~{total_reduction:.0f}% speed improvement")
        print(f"• Reduced bandwidth: {(total_original - total_compressed)/1024:.1f} KB saved per visitor")
        print(f"• Better mobile experience: Especially important for slower connections")
        print(f"• SEO improvement: Google favors faster-loading sites")
        print()
        
        print("💾 BACKUP FILES CREATED:")
        for file_info in compressed_files:
            print(f"• {file_info['backup']}")
        
        print()
        print("🌐 GZIP FILES CREATED:")
        print("Pre-compressed .gz files created for server optimization")
        for file_info in compressed_files:
            print(f"• {file_info['name']}.gz")
        
        print()
        print("✨ Website compression complete! The KW Wizards site is now optimized for speed.")
    else:
        print("❌ No files were successfully compressed.")

if __name__ == "__main__":
    main()
