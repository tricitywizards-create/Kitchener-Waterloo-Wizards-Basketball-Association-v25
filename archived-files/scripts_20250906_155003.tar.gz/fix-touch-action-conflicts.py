#!/usr/bin/env python3
"""
Fix Touch-Action CSS Conflicts
Kitchener-Waterloo Wizards Basketball Association

Critical mobile performance issue: Conflicting touch-action rules
- touch-action: pan-y !important;
- touch-action: manipulation !important;

This script resolves conflicts by creating a proper hierarchy:
1. Default: pan-y for scrollable content
2. Interactive elements: manipulation for buttons/links
3. Proper specificity to avoid conflicts
"""

import os
import re
import glob

def fix_touch_action_conflicts(content):
    """Fix conflicting touch-action rules with proper CSS hierarchy"""
    
    # Critical Fix: Remove conflicting global touch-action rules
    fixes = [
        # Fix 1: Remove the global pan-y rule that conflicts with interactive elements
        (r'(\*\s*\{[^}]*)-webkit-tap-highlight-color:\s*transparent\s*!\s*important;[^}]*touch-action:\s*pan-y\s*!\s*important;([^}]*\})', 
         r'\1-webkit-tap-highlight-color: transparent !important;\2'),
        
        # Fix 2: Ensure interactive elements have proper touch-action hierarchy
        (r'(a,\s*button,\s*\.btn[^}]*touch-action:\s*)pan-y(\s*!\s*important)', 
         r'\1manipulation\2'),
         
        # Fix 3: Create specific rules for scrollable vs interactive content
        (r'touch-action:\s*pan-y\s*!\s*important;([^}]*touch-action:\s*manipulation)', 
         r'/* Fixed touch-action conflict */ touch-action: manipulation'),
    ]
    
    for pattern, replacement in fixes:
        content = re.sub(pattern, replacement, content, flags=re.DOTALL)
    
    return content

def add_optimized_touch_action_css(content):
    """Add optimized touch-action CSS hierarchy"""
    
    optimized_css = '''
/* TOUCH-ACTION OPTIMIZATION - Resolve Conflicts */
@media (max-width: 768px) {
  /* Base rule: Allow vertical scrolling */
  * {
    touch-action: pan-y;
  }
  
  /* Interactive elements: Allow all gestures */
  a, button, .btn, input, select, textarea, 
  .menu-toggle, .mobile-social-icons a, 
  .nav-links a, .rep-team-box, 
  [role="button"], [onclick] {
    touch-action: manipulation !important;
  }
  
  /* Scrollable containers: Allow pan gestures */
  .nav-links, main, section, 
  .calendar-box, html, body {
    touch-action: pan-y pan-x;
  }
  
  /* Text content: Allow selection */
  p, span, h1, h2, h3, h4, h5, h6, 
  .header-text, .tagline {
    touch-action: pan-y;
    -webkit-user-select: text;
    user-select: text;
  }
}'''
    
    # Find insertion point after existing touch-action rules
    insertion_points = [
        '}.mobile-nav-top',
        '}.nav-links a:hover',
        '@media (max-width:768px)',
    ]
    
    for point in insertion_points:
        if point in content:
            insertion_index = content.find(point) + len(point)
            content = content[:insertion_index] + optimized_css + content[insertion_index:]
            break
    
    return content

def clean_redundant_touch_actions(content):
    """Remove redundant and conflicting touch-action declarations"""
    
    # Remove duplicate touch-action rules within the same selector
    patterns_to_clean = [
        # Remove redundant touch-action: pan-y when manipulation is present
        (r'(touch-action:\s*pan-y[^;}]*;[^}]*touch-action:\s*manipulation[^;}]*)', 
         r'touch-action: manipulation'),
        
        # Remove excessive !important declarations
        (r'touch-action:\s*([^;]*)\s*!\s*important\s*!\s*important', 
         r'touch-action: \1 !important'),
         
        # Consolidate multiple touch-action rules
        (r'touch-action:\s*[^;}]*;\s*([^}]*)\s*touch-action:\s*([^;}]*);', 
         r'touch-action: \2; \1'),
    ]
    
    for pattern, replacement in patterns_to_clean:
        content = re.sub(pattern, replacement, content, flags=re.DOTALL)
    
    return content

def fix_css_specificity_conflicts(content):
    """Fix CSS specificity conflicts that cause touch-action issues"""
    
    # Ensure proper CSS cascade for touch actions
    specificity_fixes = [
        # Make interactive element selectors more specific
        (r'(a,\s*button,\s*\.btn\{[^}]*touch-action:\s*manipulation[^}]*\})', 
         r'/* High specificity for interactive elements */\na:not([disabled]), button:not([disabled]), .btn:not([disabled]) {\n  touch-action: manipulation !important;\n}'),
        
        # Ensure mobile-specific rules override global rules
        (r'(@media[^{]*max-width:\s*768px[^{]*\{)', 
         r'\1\n  /* Mobile touch-action hierarchy */'),
    ]
    
    for pattern, replacement in specificity_fixes:
        content = re.sub(pattern, replacement, content, flags=re.DOTALL)
    
    return content

def process_html_file(filepath):
    """Process HTML file to fix touch-action conflicts"""
    print(f"Processing: {filepath}")
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    original_content = content
    
    # Count original conflicts
    pan_y_count = len(re.findall(r'touch-action:\s*pan-y', content))
    manipulation_count = len(re.findall(r'touch-action:\s*manipulation', content))
    
    # Apply fixes
    content = fix_touch_action_conflicts(content)
    content = clean_redundant_touch_actions(content)
    content = fix_css_specificity_conflicts(content)
    content = add_optimized_touch_action_css(content)
    
    # Count after fixes
    new_pan_y_count = len(re.findall(r'touch-action:\s*pan-y', content))
    new_manipulation_count = len(re.findall(r'touch-action:\s*manipulation', content))
    
    if content != original_content:
        # Create backup
        backup_path = f"{filepath}.touch-backup"
        if not os.path.exists(backup_path):
            with open(backup_path, 'w', encoding='utf-8') as f:
                f.write(original_content)
        
        # Write fixed content
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        
        print(f"  ✅ Fixed touch-action conflicts")
        print(f"  📊 Before: pan-y({pan_y_count}) + manipulation({manipulation_count})")
        print(f"  📊 After: pan-y({new_pan_y_count}) + manipulation({new_manipulation_count})")
        print(f"  🎯 Optimized CSS hierarchy added")
        return True
    else:
        print(f"  ℹ️  No touch-action conflicts found")
        return False

def process_css_file(filepath):
    """Process standalone CSS files"""
    print(f"Processing CSS: {filepath}")
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    original_content = content
    
    # Apply CSS-specific fixes
    content = fix_touch_action_conflicts(content)
    content = clean_redundant_touch_actions(content)
    
    if content != original_content:
        # Create backup
        backup_path = f"{filepath}.touch-backup"
        if not os.path.exists(backup_path):
            with open(backup_path, 'w', encoding='utf-8') as f:
                f.write(original_content)
        
        # Write fixed content
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        
        print(f"  ✅ CSS touch-action conflicts resolved")
        return True
    else:
        print(f"  ℹ️  No CSS conflicts found")
        return False

def main():
    """Main function to fix all touch-action conflicts"""
    print("🔧 FIXING TOUCH-ACTION CSS CONFLICTS")
    print("=" * 60)
    print("CRITICAL ISSUE: Conflicting touch-action rules cause mobile lag")
    print("FIX: Create proper CSS hierarchy for touch interactions")
    print("")
    
    # Get all relevant files
    html_files = glob.glob("*.html")
    css_files = glob.glob("*.css")
    
    # Priority files (main pages with conflicts)
    priority_files = [
        "index.html",
        "registration.html", 
        "about.html",
        "rep-teams.html",
        "development.html",
        "individual-training.html",
        "upcoming-events.html",
        "photo-gallery.html"
    ]
    
    fixed_count = 0
    total_files = 0
    
    # Process priority HTML files first
    print("🎯 FIXING MAIN PAGES:")
    for filename in priority_files:
        if os.path.exists(filename):
            total_files += 1
            if process_html_file(filename):
                fixed_count += 1
    
    # Process CSS files
    print("\n🎨 FIXING CSS FILES:")
    for filename in css_files:
        if os.path.exists(filename) and not filename.endswith('.backup'):
            total_files += 1
            if process_css_file(filename):
                fixed_count += 1
    
    # Process remaining HTML files
    print("\n📄 CHECKING OTHER HTML FILES:")
    for filepath in html_files:
        if filepath not in priority_files and not filepath.endswith('.backup'):
            total_files += 1
            if process_html_file(filepath):
                fixed_count += 1
    
    print("\n" + "=" * 60)
    print("🎯 TOUCH-ACTION CONFLICT RESOLUTION COMPLETE!")
    print(f"✅ Fixed {fixed_count} files out of {total_files} total files")
    
    print("\n🔧 TOUCH-ACTION OPTIMIZATIONS APPLIED:")
    print("  • Resolved conflicting pan-y vs manipulation rules")
    print("  • Created proper CSS specificity hierarchy")
    print("  • Interactive elements: touch-action: manipulation")
    print("  • Scrollable content: touch-action: pan-y")
    print("  • Removed redundant !important declarations")
    print("  • Added mobile-specific touch optimization")
    
    print("\n⚡ MOBILE PERFORMANCE IMPROVEMENTS:")
    print("  • Eliminated touch-action rule conflicts")
    print("  • Consistent mobile touch behavior")
    print("  • Better scroll performance on mobile")
    print("  • Proper button/link touch handling")
    print("  • No more CSS cascade conflicts")
    
    print("\n💯 Your mobile touch interactions are now conflict-free!")
    print("🏀 Users will experience smooth, responsive touch controls!")

if __name__ == "__main__":
    main()
