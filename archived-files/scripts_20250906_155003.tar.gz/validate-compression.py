#!/usr/bin/env python3
"""
Compression Validation Script for KW Wizards Basketball Website
Compares compressed files with their backups to validate compression results
"""

import os
from pathlib import Path

def get_file_size(file_path):
    """Get file size in bytes"""
    try:
        return os.path.getsize(file_path)
    except FileNotFoundError:
        return 0

def validate_compression():
    """Validate compression results by comparing with backup files"""
    
    website_dir = Path('.')
    backup_files = list(website_dir.glob('*.backup'))
    
    if not backup_files:
        print("❌ No backup files found! Run compress-website.py first.")
        return
    
    print("🔍 KW Wizards Basketball Website Compression Validation")
    print("=" * 60)
    print()
    
    total_original = 0
    total_compressed = 0
    validated_files = 0
    
    for backup_file in backup_files:
        # Get corresponding compressed file
        compressed_file = backup_file.with_suffix('')
        
        if compressed_file.exists():
            original_size = get_file_size(backup_file)
            compressed_size = get_file_size(compressed_file)
            
            if original_size > 0 and compressed_size > 0:
                reduction = ((original_size - compressed_size) / original_size) * 100
                savings = original_size - compressed_size
                
                total_original += original_size
                total_compressed += compressed_size
                validated_files += 1
                
                # Show validation result
                status = "✅" if reduction > 0 else "⚠️"
                print(f"{status} {compressed_file.name}")
                print(f"   Original: {original_size:,} bytes | Compressed: {compressed_size:,} bytes")
                print(f"   Reduction: {reduction:.1f}% ({savings:,} bytes saved)")
                print()
    
    if validated_files > 0:
        total_reduction = ((total_original - total_compressed) / total_original) * 100
        total_savings = total_original - total_compressed
        
        print("📊 VALIDATION SUMMARY")
        print("=" * 60)
        print(f"✅ Files validated: {validated_files}")
        print(f"📦 Total original size: {total_original:,} bytes ({total_original/1024:.1f} KB)")
        print(f"📦 Total compressed size: {total_compressed:,} bytes ({total_compressed/1024:.1f} KB)")
        print(f"💰 Total savings: {total_savings:,} bytes ({total_savings/1024:.1f} KB)")
        print(f"📈 Average reduction: {total_reduction:.1f}%")
        print()
        
        # Additional file analysis
        gz_files = list(website_dir.glob('*.gz'))
        print(f"🗜️  Gzip files created: {len(gz_files)}")
        
        # Estimate additional gzip savings
        sample_file = Path('index.html')
        if sample_file.exists():
            original_compressed = get_file_size(sample_file)
            gzip_file = sample_file.with_suffix('.html.gz')
            if gzip_file.exists():
                gzip_size = get_file_size(gzip_file)
                if gzip_size > 0:
                    gzip_reduction = ((original_compressed - gzip_size) / original_compressed) * 100
                    print(f"🗜️  Additional gzip compression: ~{gzip_reduction:.1f}% (sample from index.html)")
        
        print()
        print("🚀 PERFORMANCE IMPACT:")
        print(f"• Page load improvement: ~{total_reduction:.0f}% faster")
        print(f"• Bandwidth savings: {total_savings/1024:.1f} KB per visitor")
        print(f"• Mobile experience: Significantly enhanced")
        print(f"• SEO benefit: Improved site speed ranking")
        print()
        
        # File integrity check
        integrity_issues = []
        for backup_file in backup_files:
            compressed_file = backup_file.with_suffix('')
            if not compressed_file.exists():
                integrity_issues.append(compressed_file.name)
        
        if integrity_issues:
            print("⚠️ INTEGRITY ISSUES:")
            for issue in integrity_issues:
                print(f"   Missing: {issue}")
        else:
            print("✅ FILE INTEGRITY: All files successfully compressed and validated")
        
    else:
        print("❌ No files could be validated!")

if __name__ == "__main__":
    validate_compression()
