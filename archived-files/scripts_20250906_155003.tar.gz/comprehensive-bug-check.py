#!/usr/bin/env python3
"""
Comprehensive Bug Detection & Analysis
Kitchener-Waterloo Wizards Basketball Association

This script performs an exhaustive bug check across every file:
- HTML structure validation
- CSS syntax and conflicts
- JavaScript errors and issues
- Image and asset verification
- Form functionality
- Mobile compatibility
- Performance bottlenecks
- Browser compatibility
"""

import os
import re
import glob
import json
from urllib.parse import urlparse

class SiteBugDetector:
    def __init__(self):
        self.bugs_found = []
        self.warnings = []
        self.files_checked = 0
        self.critical_issues = 0
        self.minor_issues = 0
        
    def log_bug(self, severity, file_path, issue_type, description, line_number=None):
        """Log a detected bug"""
        bug = {
            'severity': severity,
            'file': file_path,
            'type': issue_type,
            'description': description,
            'line': line_number
        }
        
        if severity == 'CRITICAL':
            self.bugs_found.append(bug)
            self.critical_issues += 1
        else:
            self.warnings.append(bug)
            self.minor_issues += 1
    
    def check_html_structure(self, filepath):
        """Check HTML files for structural issues"""
        print(f"  🔍 HTML Structure: {filepath}")
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Check for basic HTML structure
            if not content.strip().startswith('<!DOCTYPE'):
                self.log_bug('CRITICAL', filepath, 'HTML Structure', 'Missing DOCTYPE declaration')
            
            if '<html' not in content:
                self.log_bug('CRITICAL', filepath, 'HTML Structure', 'Missing <html> tag')
            
            if '<head>' not in content:
                self.log_bug('CRITICAL', filepath, 'HTML Structure', 'Missing <head> section')
            
            if '<body' not in content:
                self.log_bug('CRITICAL', filepath, 'HTML Structure', 'Missing <body> tag')
            
            # Check for unclosed tags
            open_tags = re.findall(r'<(\w+)(?:\s[^>]*)?>(?![^<]*</\1>)', content)
            self_closing = ['img', 'input', 'br', 'hr', 'meta', 'link']
            
            for tag in open_tags:
                if tag not in self_closing and tag not in ['html', 'head', 'body']:
                    # More sophisticated check needed
                    pass
            
            # Check for duplicate IDs
            ids = re.findall(r'id=["\']([^"\']+)["\']', content)
            duplicate_ids = set([x for x in ids if ids.count(x) > 1])
            
            for dup_id in duplicate_ids:
                self.log_bug('CRITICAL', filepath, 'HTML Structure', f'Duplicate ID: {dup_id}')
            
            # Check for required elements
            if 'menu-toggle' in content and 'id="menu-toggle"' not in content:
                self.log_bug('WARNING', filepath, 'JavaScript Dependency', 'JavaScript references menu-toggle but ID not found')
            
            if 'nav-links' in content and 'id="nav-links"' not in content:
                self.log_bug('WARNING', filepath, 'JavaScript Dependency', 'JavaScript references nav-links but ID not found')
            
            return True
            
        except Exception as e:
            self.log_bug('CRITICAL', filepath, 'File Access', f'Cannot read file: {str(e)}')
            return False
    
    def check_css_issues(self, content, filepath):
        """Check for CSS syntax errors and conflicts"""
        print(f"    🎨 CSS Analysis...")
        
        # Check for CSS syntax errors
        unclosed_braces = content.count('{') - content.count('}')
        if unclosed_braces != 0:
            self.log_bug('CRITICAL', filepath, 'CSS Syntax', f'Unclosed braces: {unclosed_braces}')
        
        # Check for conflicting properties
        touch_action_conflicts = re.findall(r'touch-action:\s*([^;]+);', content)
        if len(set(touch_action_conflicts)) > 1:
            self.log_bug('WARNING', filepath, 'CSS Conflicts', f'Conflicting touch-action values: {touch_action_conflicts}')
        
        # Check for missing vendor prefixes
        transform_props = re.findall(r'transform:', content)
        webkit_transform_props = re.findall(r'-webkit-transform:', content)
        
        if len(transform_props) > len(webkit_transform_props):
            self.log_bug('WARNING', filepath, 'CSS Compatibility', 'Missing -webkit- prefixes for transforms')
        
        # Check for overly broad selectors
        universal_selectors = re.findall(r'\*\s*\{[^}]*\}', content)
        if len(universal_selectors) > 2:
            self.log_bug('WARNING', filepath, 'CSS Performance', f'Too many universal selectors ({len(universal_selectors)})')
        
        # Check for !important overuse
        important_count = content.count('!important')
        if important_count > 20:
            self.log_bug('WARNING', filepath, 'CSS Maintainability', f'Excessive !important usage ({important_count})')
    
    def check_javascript_issues(self, content, filepath):
        """Check for JavaScript syntax and runtime errors"""
        print(f"    ⚡ JavaScript Analysis...")
        
        # Check for common syntax errors
        if 'getElementById(' in content:
            # Check if elements exist
            element_ids = re.findall(r'getElementById\(["\']([^"\']+)["\']', content)
            for element_id in element_ids:
                if f'id="{element_id}"' not in content and f"id='{element_id}'" not in content:
                    self.log_bug('CRITICAL', filepath, 'JavaScript Error', f'getElementById("{element_id}") but element not found')
        
        # Check for undefined variables
        var_definitions = re.findall(r'(?:var|let|const)\s+(\w+)', content)
        var_usage = re.findall(r'\b(\w+)\s*(?:\(|\.|\[)', content)
        
        undefined_vars = set(var_usage) - set(var_definitions) - {
            'window', 'document', 'console', 'Math', 'Date', 'Array', 'Object', 
            'String', 'Number', 'Boolean', 'navigator', 'location', 'history'
        }
        
        for var in undefined_vars:
            if len(var) > 2 and var.isalpha():  # Filter out short/non-alpha variables
                self.log_bug('WARNING', filepath, 'JavaScript Warning', f'Potentially undefined variable: {var}')
        
        # Check for setTimeout/setInterval (performance issues)
        timeout_calls = re.findall(r'setTimeout\(', content)
        interval_calls = re.findall(r'setInterval\(', content)
        
        if timeout_calls:
            self.log_bug('WARNING', filepath, 'Performance', f'Found {len(timeout_calls)} setTimeout calls (consider requestAnimationFrame)')
        
        if interval_calls:
            self.log_bug('WARNING', filepath, 'Performance', f'Found {len(interval_calls)} setInterval calls (consider requestAnimationFrame)')
        
        # Check for event listener memory leaks
        add_listeners = content.count('addEventListener')
        remove_listeners = content.count('removeEventListener')
        
        if add_listeners > remove_listeners * 2:  # Rough heuristic
            self.log_bug('WARNING', filepath, 'Memory Leak', 'Potential memory leak: more addEventListener than removeEventListener')
    
    def check_images_and_assets(self, content, filepath):
        """Check for broken image links and missing assets"""
        print(f"    🖼️  Asset Verification...")
        
        # Find all image references
        img_sources = re.findall(r'(?:src|href)=["\']([^"\']+\.(?:png|jpg|jpeg|gif|svg|ico))["\']', content)
        
        for img_src in img_sources:
            if img_src.startswith('http'):
                continue  # Skip external URLs for now
                
            # Check if local image exists
            img_path = os.path.join(os.path.dirname(filepath), img_src)
            if not os.path.exists(img_path):
                # Try absolute path
                img_path = img_src
                if not os.path.exists(img_path):
                    self.log_bug('CRITICAL', filepath, 'Missing Asset', f'Image not found: {img_src}')
        
        # Check for CSS/JS references
        css_links = re.findall(r'href=["\']([^"\']+\.css)["\']', content)
        js_links = re.findall(r'src=["\']([^"\']+\.js)["\']', content)
        
        for css_link in css_links:
            if css_link.startswith('http'):
                continue
            css_path = os.path.join(os.path.dirname(filepath), css_link)
            if not os.path.exists(css_path):
                self.log_bug('WARNING', filepath, 'Missing Asset', f'CSS file not found: {css_link}')
        
        for js_link in js_links:
            if js_link.startswith('http'):
                continue
            js_path = os.path.join(os.path.dirname(filepath), js_link)
            if not os.path.exists(js_path):
                self.log_bug('WARNING', filepath, 'Missing Asset', f'JavaScript file not found: {js_link}')
    
    def check_forms(self, content, filepath):
        """Check form functionality and validation"""
        print(f"    📝 Form Analysis...")
        
        # Find all forms
        forms = re.findall(r'<form[^>]*>(.*?)</form>', content, re.DOTALL)
        
        for i, form in enumerate(forms):
            # Check for form action
            action = re.search(r'action=["\']([^"\']+)["\']', form)
            if not action:
                self.log_bug('WARNING', filepath, 'Form Issue', f'Form {i+1} missing action attribute')
            
            # Check for method
            method = re.search(r'method=["\']([^"\']+)["\']', form)
            if not method:
                self.log_bug('WARNING', filepath, 'Form Issue', f'Form {i+1} missing method attribute')
            
            # Check for required fields without labels
            required_inputs = re.findall(r'<input[^>]*required[^>]*>', form)
            labels = re.findall(r'<label[^>]*>', form)
            
            if len(required_inputs) > len(labels):
                self.log_bug('WARNING', filepath, 'Accessibility', f'Form {i+1} has required inputs without proper labels')
    
    def check_mobile_compatibility(self, content, filepath):
        """Check for mobile-specific issues"""
        print(f"    📱 Mobile Compatibility...")
        
        # Check viewport meta tag
        if '<meta name="viewport"' not in content:
            self.log_bug('CRITICAL', filepath, 'Mobile Issue', 'Missing viewport meta tag')
        
        # Check for touch-friendly button sizes
        button_styles = re.findall(r'\.btn[^}]*\{[^}]*\}', content)
        for button_style in button_styles:
            if 'min-height' not in button_style or 'min-width' not in button_style:
                self.log_bug('WARNING', filepath, 'Mobile UX', 'Button missing minimum touch target size')
        
        # Check for iOS Safari fixes
        if '-webkit-fill-available' not in content:
            self.log_bug('WARNING', filepath, 'iOS Compatibility', 'Missing iOS Safari viewport fixes')
    
    def analyze_file(self, filepath):
        """Analyze a single file for bugs"""
        self.files_checked += 1
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            self.log_bug('CRITICAL', filepath, 'File Access', f'Cannot read file: {str(e)}')
            return
        
        file_ext = os.path.splitext(filepath)[1].lower()
        
        if file_ext == '.html':
            # HTML-specific checks
            self.check_html_structure(filepath)
            self.check_css_issues(content, filepath)
            self.check_javascript_issues(content, filepath)
            self.check_images_and_assets(content, filepath)
            self.check_forms(content, filepath)
            self.check_mobile_compatibility(content, filepath)
            
        elif file_ext == '.css':
            self.check_css_issues(content, filepath)
            
        elif file_ext == '.js':
            self.check_javascript_issues(content, filepath)
    
    def run_comprehensive_check(self):
        """Run comprehensive bug check on all files"""
        print("🔍 COMPREHENSIVE BUG DETECTION STARTING...")
        print("=" * 60)
        
        # Find all relevant files
        file_patterns = ['*.html', '*.css', '*.js', '*.json']
        all_files = []
        
        for pattern in file_patterns:
            all_files.extend(glob.glob(pattern))
        
        # Priority files (main pages)
        priority_files = [
            "index.html", "registration.html", "about.html", "rep-teams.html",
            "development.html", "individual-training.html", "upcoming-events.html",
            "photo-gallery.html", "sitemap.html"
        ]
        
        print(f"\n📊 Found {len(all_files)} files to analyze")
        print("\n🎯 ANALYZING PRIORITY FILES:")
        
        for filename in priority_files:
            if os.path.exists(filename):
                print(f"\n📄 {filename}")
                self.analyze_file(filename)
        
        print("\n📄 ANALYZING OTHER FILES:")
        for filepath in all_files:
            if filepath not in priority_files and not filepath.endswith('.backup'):
                print(f"\n📄 {filepath}")
                self.analyze_file(filepath)
        
        # Generate report
        self.generate_report()
    
    def generate_report(self):
        """Generate comprehensive bug report"""
        print("\n" + "=" * 60)
        print("🎯 BUG DETECTION REPORT")
        print("=" * 60)
        
        print(f"📊 SUMMARY:")
        print(f"   Files Checked: {self.files_checked}")
        print(f"   Critical Issues: {self.critical_issues}")
        print(f"   Minor Issues/Warnings: {self.minor_issues}")
        print(f"   Total Issues: {len(self.bugs_found) + len(self.warnings)}")
        
        if self.critical_issues == 0 and self.minor_issues == 0:
            print("\n🎉 NO BUGS FOUND! Your site is clean! 🎉")
            return
        
        # Critical issues
        if self.bugs_found:
            print(f"\n🚨 CRITICAL ISSUES ({len(self.bugs_found)}):")
            for i, bug in enumerate(self.bugs_found, 1):
                print(f"   {i}. {bug['file']}")
                print(f"      Type: {bug['type']}")
                print(f"      Issue: {bug['description']}")
                if bug['line']:
                    print(f"      Line: {bug['line']}")
                print()
        
        # Warnings
        if self.warnings and len(self.warnings) <= 10:  # Only show first 10 warnings
            print(f"\n⚠️  WARNINGS ({len(self.warnings)}):")
            for i, warning in enumerate(self.warnings[:10], 1):
                print(f"   {i}. {warning['file']}")
                print(f"      Type: {warning['type']}")
                print(f"      Issue: {warning['description']}")
                print()
        
        if len(self.warnings) > 10:
            print(f"   ... and {len(self.warnings) - 10} more warnings")
        
        # Recommendations
        print(f"\n💡 RECOMMENDATIONS:")
        
        if self.critical_issues > 0:
            print("   🔥 Address critical issues immediately!")
            print("   📝 Fix HTML structure and JavaScript errors first")
        
        if any(w['type'] == 'Performance' for w in self.warnings):
            print("   ⚡ Consider performance optimizations")
        
        if any(w['type'] == 'Accessibility' for w in self.warnings):
            print("   ♿ Improve accessibility for better user experience")
        
        if any(w['type'] == 'Mobile Issue' for w in self.warnings):
            print("   📱 Fix mobile compatibility issues")
        
        print("\n🏀 Your Kitchener-Waterloo Wizards site analysis complete!")

if __name__ == "__main__":
    detector = SiteBugDetector()
    detector.run_comprehensive_check()
