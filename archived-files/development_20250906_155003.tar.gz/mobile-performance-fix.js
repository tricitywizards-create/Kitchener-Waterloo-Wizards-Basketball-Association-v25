// CRITICAL MOBILE PERFORMANCE FIXES
// Kitchener-Waterloo Wizards Basketball Association
// Fixes: DOM manipulation performance, star animation optimization, cached viewport handling

(function() {
'use strict';

// Performance-optimized mobile detection
const isMobile = () => {
  return window.innerWidth <= 768 || 
         /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
};

// CRITICAL FIX #1: Cached DOM Elements
// Instead of querying DOM on every interaction, cache elements once
const navElements = {};

function cacheNavigationElements() {
  navElements.toggle = document.getElementById('menu-toggle');
  navElements.links = document.getElementById('nav-links');
  navElements.logo = document.querySelector('.nav-logo');
  navElements.nav = document.querySelector('nav');
}

// CRITICAL FIX #2: Optimized Viewport Height Calculation
let cachedVH = 0;
let viewportUpdateScheduled = false;

function updateViewportHeight() {
  if (!isMobile()) return;
  
  const newVH = window.innerHeight * 0.01;
  
  // Only update if there's a significant change (>0.2px) to prevent layout thrashing
  if (Math.abs(newVH - cachedVH) > 0.2) {
    document.documentElement.style.setProperty('--vh', newVH + 'px');
    cachedVH = newVH;
  }
  
  viewportUpdateScheduled = false;
}

function scheduleViewportUpdate() {
  if (!viewportUpdateScheduled) {
    viewportUpdateScheduled = true;
    requestAnimationFrame(updateViewportHeight);
  }
}

// CRITICAL FIX #3: Ultra-lightweight Star Animation
function createOptimizedStars() {
  const starContainer = document.getElementById('stars');
  if (!starContainer) return;
  
  // Drastically reduced star count for mobile performance
  const starCount = isMobile() ? 3 : 15; // Was 8-50, now 3-15
  const fragment = document.createDocumentFragment();
  
  // Create stars with GPU acceleration from the start
  for (let i = 0; i < starCount; i++) {
    const star = document.createElement('div');
    star.className = 'star';
    star.style.cssText = `
      position: absolute;
      width: 1px;
      height: 1px;
      left: ${Math.random() * 100}%;
      top: ${Math.random() * 100}%;
      background: #fff;
      border-radius: 50%;
      opacity: ${Math.random() * 0.3 + 0.1};
      will-change: opacity;
      transform: translate3d(0, 0, 0);
      animation: star-fade ${3 + Math.random() * 2}s ease-in-out infinite;
      animation-delay: ${Math.random() * 2}s;
    `;
    fragment.appendChild(star);
  }
  
  starContainer.appendChild(fragment);
  
  // Add minimal CSS animation (GPU-optimized)
  if (!document.querySelector('#star-animation')) {
    const style = document.createElement('style');
    style.id = 'star-animation';
    style.textContent = `
      @keyframes star-fade {
        0%, 100% { opacity: 0.1; }
        50% { opacity: 0.4; }
      }
      @media (prefers-reduced-motion: reduce) {
        .star { animation: none !important; opacity: 0.2 !important; }
      }
    `;
    document.head.appendChild(style);
  }
}

// CRITICAL FIX #4: Optimized Navigation with Cached Elements
function initializeNavigation() {
  if (!navElements.toggle || !navElements.links) return;
  
  // Use cached elements instead of DOM queries
  navElements.toggle.addEventListener('click', (e) => {
    e.preventDefault();
    
    const isActive = navElements.links.classList.contains('active');
    
    // Batch DOM changes to prevent layout thrashing
    requestAnimationFrame(() => {
      navElements.links.classList.toggle('active');
      navElements.toggle.classList.toggle('active');
      
      if (navElements.logo) {
        navElements.logo.classList.toggle('hidden');
      }
    });
  }, { passive: false });
  
  // Close menu when clicking nav links
  navElements.links.addEventListener('click', (e) => {
    if (e.target.tagName === 'A') {
      requestAnimationFrame(() => {
        navElements.links.classList.remove('active');
        navElements.toggle.classList.remove('active');
        if (navElements.logo) {
          navElements.logo.classList.remove('hidden');
        }
      });
    }
  }, { passive: true });
  
  // Close menu when clicking outside (with cached nav element)
  document.addEventListener('click', (e) => {
    if (!navElements.nav.contains(e.target) && navElements.links.classList.contains('active')) {
      requestAnimationFrame(() => {
        navElements.links.classList.remove('active');
        navElements.toggle.classList.remove('active');
        if (navElements.logo) {
          navElements.logo.classList.remove('hidden');
        }
      });
    }
  }, { passive: true });
}

// CRITICAL FIX #5: Performance-optimized Event Listeners
function initializePerformanceOptimizations() {
  // Viewport height optimization with caching
  if (isMobile()) {
    cachedVH = window.innerHeight * 0.01;
    document.documentElement.style.setProperty('--vh', cachedVH + 'px');
    
    // Use passive listeners with optimized scheduling
    window.addEventListener('resize', scheduleViewportUpdate, { passive: true });
    window.addEventListener('orientationchange', () => {
      // Small delay for orientation to complete
      setTimeout(() => {
        scheduleViewportUpdate();
      }, 100);
    }, { passive: true });
  }
  
  // Optimize scroll performance with minimal handling
  let scrollTicking = false;
  window.addEventListener('scroll', () => {
    if (!scrollTicking) {
      scrollTicking = true;
      requestAnimationFrame(() => {
        // Minimal scroll handling - only nav collapse
        const nav = navElements.nav || document.querySelector('nav');
        if (nav) {
          if (window.pageYOffset > 100) {
            nav.classList.add('collapsed');
          } else {
            nav.classList.remove('collapsed');
          }
        }
        scrollTicking = false;
      });
    }
  }, { passive: true });
}

// CRITICAL FIX #6: Reduced Motion Support
function respectUserPreferences() {
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  
  if (prefersReducedMotion) {
    document.documentElement.style.setProperty('--animation-duration', '0.01s');
    document.body.classList.add('reduce-motion');
  }
}

// Initialize all performance optimizations
function initializeMobilePerformance() {
  // Remove loading state immediately
  document.body.classList.remove('loading');
  document.body.classList.add('loaded');
  
  // Cache DOM elements once
  cacheNavigationElements();
  
  // Initialize components
  initializeNavigation();
  initializePerformanceOptimizations();
  respectUserPreferences();
  
  // Initialize stars with minimal delay
  if (document.readyState === 'complete') {
    createOptimizedStars();
  } else {
    window.addEventListener('load', createOptimizedStars, { once: true });
  }
}

// Start optimization based on document state
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeMobilePerformance);
} else {
  initializeMobilePerformance();
}

})();

// Export performance utilities for debugging
window.MobilePerformance = {
  isMobile,
  updateViewportHeight,
  cachedVH: () => cachedVH,
  elementsCached: () => Object.keys(navElements).length > 0
};
